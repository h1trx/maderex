export const navig = (url) => {
    window.open(url, "_blank")
}